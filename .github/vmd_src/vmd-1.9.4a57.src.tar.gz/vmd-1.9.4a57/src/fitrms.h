#ifdef __cplusplus
extern "C" {
#endif

void MatrixFitRMS(int n, float *v1, float *v2, const float *wt, float *ttt);

#ifdef __cplusplus
}
#endif
