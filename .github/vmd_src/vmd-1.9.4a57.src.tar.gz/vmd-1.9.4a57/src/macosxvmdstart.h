/**
 *  \file macosxvmdstart.h
 *  \brief MacOS X platform specific application startup code.
 */
int macosxvmdstart(int argc, char **argv);
